n=int(input("ingrese un numero de cuatro a diez digitos: "))
#no pude profe :c 