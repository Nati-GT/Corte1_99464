n=int(input("indique la cantidad de numeros primos: "))
while n<=n:
    if n/n//10:
        n+=1
        break
    print(n)
    n+=1
print('fin del proceso')